package ma.xproce.inventoryservice.web;

import ma.xproce.inventoryservice.service.IngenierieManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.io.ByteArrayInputStream;

@Controller
public class IndexController {

    @Autowired
    private IngenierieManagerService ingenierieService;

    @GetMapping("/index")
    public String indexPage() {
        return "index";
    }

    @GetMapping("/ingenierie/download/{id}")
    public ResponseEntity<InputStreamResource> downloadWord(@PathVariable Long id) {
        ByteArrayInputStream bis = ingenierieService.generateWordDocument(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=ingenierie.docx");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new InputStreamResource(bis));
    }
}
