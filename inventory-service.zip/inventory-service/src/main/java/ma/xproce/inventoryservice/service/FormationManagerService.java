package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.CoutFormation;
import ma.xproce.inventoryservice.dao.entities.Formation; // Changed from Video to Formation
import ma.xproce.inventoryservice.dao.repositeries.FormationDAO; // Changed from VideoDAO to FormationDAO
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class FormationManagerService implements FormationManager { // Changed from VideoManagerService to FormationManagerService
    @Autowired
    private final FormationDAO formationRepo; // Changed from VideoDAO to FormationDAO


    public ByteArrayInputStream generateWordDocument(Long id) {
        Optional<Formation> optionalFormation = formationRepo.findById(id);

        if (!optionalFormation.isPresent()) {
            throw new IllegalArgumentException("Invalid Formation ID");
        }

        Formation formation = optionalFormation.get();

        try (XWPFDocument document = new XWPFDocument()) {
            XWPFParagraph paragraph = document.createParagraph();
            XWPFRun run = paragraph.createRun();
            run.setText("le nom de formation: " + formation.getNomFormation());
            run.addBreak();
            run.setText("la description: " + formation.getDescription());
            run.addBreak();
            run.setText("la date debut : " + formation.getDateDebut());
            run.addBreak();
            run.setText("la date fin : " + formation.getDateFin());
            run.addBreak();
            run.setText("le nom d'Entreprise: " + formation.getNomEntreprise());

            try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                document.write(out);
                return new ByteArrayInputStream(out.toByteArray());
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate Word document", e);
        }
    }

    public FormationManagerService(FormationDAO formationRepo) {
        this.formationRepo = formationRepo;
    }

    @Override
    public Formation addFormation(Formation formation) { // Changed from Video to Formation
        return formationRepo.save(formation);
    }

    @Override
    public Formation updateFormation(Formation formation) { // Changed from Video to Formation
        return formationRepo.save(formation);
    }

    @Override
    public boolean deleteFormation(long id) { // Changed from Video to Formation
        formationRepo.deleteById(id);
        return true;
    }
    @Override
    public Page<Formation> searchFormation(String keyword, int page, int taille){
        return formationRepo.findByNomFormationContains(keyword, PageRequest.of(page, taille));

    }
    @Override
    public List<Formation> getAllFormations() { // Changed from Video to Formation
        return formationRepo.findAll();
    }

    @Override
    public Formation getFormationById(long id) { // Changed from Video to Formation
        return formationRepo.findById(id).orElse(null);
    }

}
