package ma.xproce.inventoryservice.web;



import jakarta.servlet.http.HttpServletResponse;
import ma.xproce.inventoryservice.dao.entities.Formation;
import ma.xproce.inventoryservice.service.FormationManagerService;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Controller
public class FormationController {
    @Autowired
    FormationManagerService formationManagerService;



    @GetMapping("/deleteFormation")
    public String deleteFormationAction(@RequestParam(name = "id") Integer id) {

        Formation formationToDelete = formationManagerService.getFormationById(id);
        boolean deletionResult = formationManagerService.deleteFormation(id);

        if (deletionResult) {
            return "redirect:/";
        } else {
            return "error";
        }
    }
    @GetMapping("/editformation")
    public String editFormationForm(Model m, @RequestParam(name = "id") Integer id) {
        Formation formation = formationManagerService.getFormationById(id);
        if (formation != null) {
            m.addAttribute("formationToBeUpdated", formation);
            return "updateFormation";
        } else {
            return "error";
        }
    }
    @PostMapping("/editformation")
    public String updateFormation(Model model,
                                  @RequestParam(name = "id") Integer id,
                                  @RequestParam(name = "nomFormation") String nomFormation,
                                  @RequestParam(name = "description") String description,
                                  @RequestParam(name = "dateDebut") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
                                  @RequestParam(name = "dateFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin,
                                  @RequestParam(name = "nomEntreprise") String nomEntreprise) { // Changed from videodesc to formationDesc
        Formation formationToUpdate = formationManagerService.getFormationById(id);
        if (formationToUpdate != null) {
            formationToUpdate.setNomFormation(nomFormation);
            formationToUpdate.setDescription(description);
            formationToUpdate.setDateDebut(dateDebut);
            formationToUpdate.setDateFin(dateFin);
            formationToUpdate.setNomEntreprise(nomEntreprise);
            formationManagerService.updateFormation(formationToUpdate);
            return "redirect:/";
        } else {
            return "error";
        }
    }

@GetMapping("/ajoutFormation" )
public String addFormationForm( ) {
    return "ajoutFormation";
}

    @PostMapping("/ajoutFormation")
    public String addFormation(Model model, @RequestParam(name = "nomFormation") String nomFormation,
                               @RequestParam(name = "dateDebut") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateDebut,
                               @RequestParam(name = "nomEntreprise") String nomEntreprise,
                               @RequestParam(name = "description") String description,
                               @RequestParam(name = "dateFin") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dateFin
    ) // Changed from videodesc to formationDesc
    {
        Formation formation = new Formation();
        formation.setNomEntreprise(nomEntreprise);
        formation.setNomFormation(nomFormation);
        formation.setDescription(description);
        formation.setDateDebut(dateDebut);
        formation.setDateFin(dateFin);

        formationManagerService.addFormation(formation);

        System.out.println("test");
        return "redirect:/";
    }


    @GetMapping("/")
    public String listFormations(Model m,
                                     @RequestParam(name = "page", defaultValue = "0") int page,
                                     @RequestParam(name = "taille", defaultValue = "3") int taille,
                                     @RequestParam(name = "search", defaultValue = "") String search) {
        Page<Formation> formations;
        formations = formationManagerService.searchFormation(search, page, taille);

        m.addAttribute("listFormation", formations.getContent());
        m.addAttribute("pages", new int[formations.getTotalPages()]);
        m.addAttribute("currentPage", page);
        m.addAttribute("search", search);
        return "indexFormation";
    }
    @GetMapping("/formation/download/{id}")
    public ResponseEntity<InputStreamResource> downloadWord(@PathVariable Long id) {
        ByteArrayInputStream bis = formationManagerService.generateWordDocument(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=formation.docx");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new InputStreamResource(bis));
    }

}



