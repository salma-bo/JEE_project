package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.Formation;
import ma.xproce.inventoryservice.dao.entities.Ingenierie;
import org.springframework.data.domain.Page;

import java.util.List;

public interface IngenierieManager {

    public Ingenierie addIngenierie(Ingenierie ingenierie);
    public Page<Ingenierie> searchIngenierie(String keyword, int page, int taille);
    public Ingenierie updateIngenierie(Ingenierie ingenierie);
    public boolean deleteIngenierie(long id);
    public List<Ingenierie> getAllIngenieries();

    public Ingenierie getIngenierieById(long id);
}
