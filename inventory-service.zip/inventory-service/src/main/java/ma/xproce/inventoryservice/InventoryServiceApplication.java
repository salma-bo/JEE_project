package ma.xproce.inventoryservice;

import ma.xproce.inventoryservice.dao.entities.Creator;
import ma.xproce.inventoryservice.dao.repositeries.CreatorDAO;
import ma.xproce.inventoryservice.dao.repositeries.FormationDAO;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class InventoryServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(InventoryServiceApplication.class, args);
    }
    @Bean
    CommandLineRunner start(CreatorDAO creatorDAO, FormationDAO formationDAO) {
        return args -> {
            /*Creator creator1 = new Creator();
            creator1.setId(123);
            creator1.setPassword("12");
            creator1.setName("salma");
            creator1.setMail("salma.saa@gmail.com");
            creatorDAO.save(creator1);
            */



        };
    }


}
