package ma.xproce.inventoryservice.dao.repositeries;

import ma.xproce.inventoryservice.dao.entities.CoutFormation;
import ma.xproce.inventoryservice.dao.entities.Formation;
import ma.xproce.inventoryservice.dao.entities.Ingenierie;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoutFormationDAO extends JpaRepository<CoutFormation,Long> {
    Page<CoutFormation> findByThemeActionContains (String keyword, Pageable pageable);
}
