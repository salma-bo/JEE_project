package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.Creator;
import ma.xproce.inventoryservice.dao.repositeries.CreatorDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CreatorManagerService implements CreatorManager{
    @Autowired
    private final CreatorDAO creatorRepo;
    @Autowired
    private CreatorDAO creatorDAO;


    public CreatorManagerService(CreatorDAO creatorRepository) {
        this.creatorRepo = creatorRepository;
    }


    @Override
    public Creator addCreator(Creator creator) {

        return creatorRepo.save(creator);
    }
    @Override
    public Creator updateCreator(Creator creator) {
        return creatorRepo.save(creator);
    }

    @Override
    public boolean deleteCreator(long id) {
        try {
            creatorRepo.deleteById(id);
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    @Override
    public Creator findByUsername(String username) {
        return creatorRepo.findByName(username).get();
    }

    @Override
    public List<Creator> getAllCreators() {
        return creatorRepo.findAll();
    }
    @Override
    public Creator getCreatorById(long id) {
        return creatorRepo.findById(id).orElse(null);
    }

    @Override
    public Page<Creator> getAllCreators(int page, int taille) {
        return creatorRepo.findAll(PageRequest.of(page, taille));

    }

    @Override
    public Optional<Creator> getCreatorByName(String creatorName) {
        return creatorRepo.findByName(creatorName);

    }

    @Override
    public Page<Creator> searchCreator(String keyword, int page, int taille){
        return creatorRepo.findByNameContains(keyword, PageRequest.of(page, taille));

    }
    @Override
    public boolean checkLogin(String username, String password) {
        Optional<Creator> existingCreator = creatorDAO.findByName(username);
        if (existingCreator.isPresent()) {
            Creator creator = existingCreator.get();
            if (creator.getPassword().equals(password)) {
                // Password matches, login successful
                return true;
            } else {
                System.out.println("Password not matchy matchy");
                return false;
            }
        } else {
            System.out.println("who are you mr " +username+" ?");
            return false;
        }
    }



}
