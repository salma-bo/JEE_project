package ma.xproce.inventoryservice.web;

import ma.xproce.inventoryservice.dao.entities.CoutFormation;
import ma.xproce.inventoryservice.service.CoutFormationManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;

@Controller
public class CoutFormationController {
    @Autowired
    CoutFormationManagerService coutFormationManagerService;

    @GetMapping("/deleteCoutFormation")
    public String deleteCoutFormation(@RequestParam(name = "id") Long id) {
        CoutFormation coutFormationToDelete = coutFormationManagerService.getCoutFormationById(id);
        boolean deletionResult = coutFormationManagerService.deleteCoutFormation(id);

        if (deletionResult) {
            return "redirect:/CoutFormation";
        } else {
            return "error";
        }
    }

    @GetMapping("/editCoutFormation")
    public String editCoutFormationForm(Model m, @RequestParam(name = "id") Long id) {
        CoutFormation coutFormation = coutFormationManagerService.getCoutFormationById(id);
        if (coutFormation != null) {
            m.addAttribute("coutFormationToBeUpdated", coutFormation);
            return "updateCoutFormation";
        } else {
            return "error";
        }
    }

    @PostMapping("/editCoutFormation")
    public String updateCoutFormation(Model model,
                                      @RequestParam(name = "id") Long id,
                                      @RequestParam(name = "themeAction") String themeAction,
                                      @RequestParam(name = "effectif") int effectif,
                                      @RequestParam(name = "nbrGrpe") int nbrGrpe,
                                      @RequestParam(name = "duree") int duree,
                                      @RequestParam(name = "prestataire") String prestataire,
                                      @RequestParam(name = "coutEstimJ") int coutEstimJ,
                                      @RequestParam(name = "coutEstimT") int coutEstimT) {
        CoutFormation coutFormationToUpdate = coutFormationManagerService.getCoutFormationById(id);
        if (coutFormationToUpdate != null) {
            coutFormationToUpdate.setThemeAction(themeAction);
            coutFormationToUpdate.setEffectif(effectif);
            coutFormationToUpdate.setNbrGrpe(nbrGrpe);
            coutFormationToUpdate.setDuree(duree);
            coutFormationToUpdate.setPrestataire(prestataire);
            coutFormationToUpdate.setCoutEstimJ(coutEstimJ);
            coutFormationToUpdate.setCoutEstimT(coutEstimT);
            coutFormationManagerService.updateCoutFormation(coutFormationToUpdate);
            return "redirect:/CoutFormation";
        } else {
            return "error";
        }
    }

    @GetMapping("/ajoutCoutFormation")
    public String addCoutFormationForm() {
        return "ajoutCoutFormation";
    }

    @PostMapping("/ajoutCoutFormation")
    public String addCoutFormation(Model model,
                                   @RequestParam(name = "themeAction") String themeAction,
                                   @RequestParam(name = "effectif") int effectif,
                                   @RequestParam(name = "nbrGrpe") int nbrGrpe,
                                   @RequestParam(name = "duree") int duree,
                                   @RequestParam(name = "prestataire") String prestataire,
                                   @RequestParam(name = "coutEstimJ") int coutEstimJ,
                                   @RequestParam(name = "coutEstimT") int coutEstimT) {
        CoutFormation coutFormation = new CoutFormation();
        coutFormation.setThemeAction(themeAction);
        coutFormation.setEffectif(effectif);
        coutFormation.setNbrGrpe(nbrGrpe);
        coutFormation.setDuree(duree);
        coutFormation.setPrestataire(prestataire);
        coutFormation.setCoutEstimJ(coutEstimJ);
        coutFormation.setCoutEstimT(coutEstimT);
        coutFormationManagerService.addCoutFormation(coutFormation);

        return "redirect:/CoutFormation";
    }

    @GetMapping("/CoutFormation")
    public String listCoutFormations(Model m,
                                     @RequestParam(name = "page", defaultValue = "0") int page,
                                     @RequestParam(name = "taille", defaultValue = "3") int taille,
                                     @RequestParam(name = "search", defaultValue = "") String search) {
        Page<CoutFormation> coutFormations = coutFormationManagerService.searchCoutFormation(search, page, taille);
        m.addAttribute("listCoutFormation", coutFormations.getContent());
        m.addAttribute("pages", new int[coutFormations.getTotalPages()]);
        m.addAttribute("currentPage", page);
        m.addAttribute("search", search);
        return "indexCoutFormation";
    }

    @GetMapping("/cout/download/{id}")
    public ResponseEntity<InputStreamResource> downloadWord(@PathVariable Long id) {
        ByteArrayInputStream bis = coutFormationManagerService.generateWordDocument(id);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=CoutFormation.docx");

        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(new InputStreamResource(bis));
    }
}
