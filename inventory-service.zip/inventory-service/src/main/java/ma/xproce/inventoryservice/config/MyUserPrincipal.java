package ma.xproce.inventoryservice.config;

import ma.xproce.inventoryservice.dao.entities.Creator;
import org.springframework.beans.factory.BeanCreationNotAllowedException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

public class MyUserPrincipal implements UserDetails {
    private Creator creator;
    private List<GrantedAuthority> authorities;
    public MyUserPrincipal(Creator creator, List<GrantedAuthority> authorities) {
        this.creator = creator;
        this.authorities = authorities;
    }
    @Override
    public Collection<GrantedAuthority> getAuthorities() {
        return List.of();
    }

    @Override
    public String getPassword() {
        return "";
    }

    @Override
    public String getUsername() {
        return creator.getName();
    }

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        return false;
    }
}