package ma.xproce.inventoryservice.web;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import ma.xproce.inventoryservice.dao.entities.Creator;
import ma.xproce.inventoryservice.dao.entities.Formation; // Changed from Video to Formation
import ma.xproce.inventoryservice.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Controller
public class CreatorController {
    @Autowired
    private CreatorManager creatorManager;
    @Autowired
    private FormationManager formationManager; // Changed from VideoManager to FormationManager

    @GetMapping("/creator")
    public String listCreator(Model m) {
        m.addAttribute("listcreator", creatorManager.getAllCreators());
        return "creatorlayout";
    }

    @GetMapping("/sign" )
    public String addCreatorForm( ) {
        return "addCreator";
    }

    @PostMapping("/sign")
    public String addCreator(Model model, @RequestParam(name = "name") String name,
                             @RequestParam(name = "mail") String mail,
                             @RequestParam(name = "password") String password,
                             @RequestParam(name = "role") String role
    ) // Changed from videodesc to formationDesc
    {
        Creator creator = new Creator();
        creator.setName(name);
        creator.setMail(mail);
        creator.setPassword(password);
        creator.setRole(role);

        creatorManager.addCreator(creator);

        System.out.println("test");
        return "redirect:/creator";
    }

    @GetMapping("/deleteCreator")
    public String deleteCreatorAction(@RequestParam(name = "id") Integer id) {

        Creator creatorToDelete = creatorManager.getCreatorById(id);
        boolean deletionResult = creatorManager.deleteCreator(id);

        if (deletionResult) {
            return "redirect:/creator";
        } else {
            return "error";
        }
    }

    @GetMapping("/editCreator")
    public String editCreatorForm(Model m, @RequestParam(name = "id") Integer id) {
        Creator creator = creatorManager.getCreatorById(id);
        if (creator != null) {
            m.addAttribute("creatorToBeUpdated", creator);
            return "updateCreator";
        } else {
            return "error";
        }
    }

    @PostMapping("/editCreator")
    public String updateCreator(Model model, @RequestParam(name = "id") Integer id,
                                @RequestParam(name = "name") String name,
                                @RequestParam(name = "mail") String mail,
                                @RequestParam(name = "password") String password) {
        Creator creatorToUpdate = creatorManager.getCreatorById(id);
        if (creatorToUpdate != null) {
            creatorToUpdate.setName(name);
            creatorToUpdate.setMail(mail);
            creatorToUpdate.setPassword(password);
            creatorManager.updateCreator(creatorToUpdate);
            return "redirect:/indexpage";
        } else {
            return "error";
        }
    }
    @GetMapping("/indexpage")
    public String listProduitsAction(Model m,
                                     @RequestParam(name = "page", defaultValue = "0") int page,
                                     @RequestParam(name = "taille", defaultValue = "3") int taille,
                                     @RequestParam(name = "search", defaultValue = "") String search) {
        Page<Creator> creators;
        creators = creatorManager.searchCreator(search, page, taille);

        m.addAttribute("listcreator", creators.getContent());
        m.addAttribute("pages", new int[creators.getTotalPages()]);
        m.addAttribute("currentPage", page);
        m.addAttribute("search", search);
        return "creatorlayout";
    }


}
