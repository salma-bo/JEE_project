package ma.xproce.inventoryservice.config;

import ma.xproce.inventoryservice.dao.entities.Creator;
import ma.xproce.inventoryservice.service.CreatorManager;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

@Service
public class MyUserDetailsService implements UserDetailsService {
    @Autowired
    CreatorManager creatorManager;
    private final CustomAuthenticationProvider customAuthenticationProvider;

    public MyUserDetailsService(CustomAuthenticationProvider customAuthenticationProvider) {
        this.customAuthenticationProvider = customAuthenticationProvider;
    }
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Creator creator = creatorManager.findByUsername(username);
        if (creator == null) {
            throw new UsernameNotFoundException("User not found: " + username);
        }
        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(creator.getRole()));
        return new MyUserPrincipal(creator, authorities);

    }


}
