package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.Ingenierie;
import ma.xproce.inventoryservice.dao.repositeries.IngenierieDAO;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class IngenierieManagerService implements IngenierieManager {
    private final IngenierieDAO ingenierieRepo;

    public ByteArrayInputStream generateWordDocument(Long id) {
        Optional<Ingenierie> optionalIngenierie = ingenierieRepo.findById(id);

        if (!optionalIngenierie.isPresent()) {
            throw new IllegalArgumentException("Invalid formation ID");
        }

        Ingenierie ingenierie = optionalIngenierie.get();

        try (XWPFDocument document = new XWPFDocument()) {
            XWPFParagraph paragraph = document.createParagraph();
            XWPFRun run = paragraph.createRun();
            run.setText("Domaine Formation: " + ingenierie.getDomaineFormation());
            run.addBreak();
            run.setText("Theme: " + ingenierie.getTheme());
            run.addBreak();
            run.setText("Objectif: " + ingenierie.getObjectif());
            run.addBreak();
            run.setText("Contenu: " + ingenierie.getContenu());
            run.addBreak();
            run.setText("Nom Entreprise: " + ingenierie.getNomEntreprise());
            run.addBreak();
            run.setText("Cadres: " + ingenierie.getCadres());
            run.addBreak();
            run.setText("Employes: " + ingenierie.getEmployes());
            run.addBreak();
            run.setText("Ouvrier: " + ingenierie.getOuvrier());
            run.addBreak();
            run.setText("Cout Formation: " + ingenierie.getCoutFormation());
            run.addBreak();
            run.setText("Date Debut: " + ingenierie.getDateDebut());
            run.addBreak();
            run.setText("Date Fin: " + ingenierie.getDateFin());

            try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                document.write(out);
                return new ByteArrayInputStream(out.toByteArray());
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate Word document", e);
        }
    }






    @Autowired
    public IngenierieManagerService(IngenierieDAO ingenierieRepo) {
        this.ingenierieRepo = ingenierieRepo;
    }

    @Override
    public Ingenierie addIngenierie(Ingenierie ingenierie) {
        return ingenierieRepo.save(ingenierie);
    }

    @Override
    public Ingenierie updateIngenierie(Ingenierie ingenierie) {
        return ingenierieRepo.save(ingenierie);
    }

    @Override
    public boolean deleteIngenierie(long id) {
        ingenierieRepo.deleteById(id);
        return true;
    }

    @Override
    public Page<Ingenierie> searchIngenierie(String keyword, int page, int taille) {
        return ingenierieRepo.findByDomaineFormationContains(keyword, PageRequest.of(page, taille));
    }

    @Override
    public List<Ingenierie> getAllIngenieries() {
        return ingenierieRepo.findAll();
    }

    @Override
    public Ingenierie getIngenierieById(long id) {
        return ingenierieRepo.findById(id).orElse(null);
    }
}
