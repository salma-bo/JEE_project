package ma.xproce.inventoryservice.service;

import ma.xproce.inventoryservice.dao.entities.CoutFormation;
import ma.xproce.inventoryservice.dao.entities.Ingenierie;
import ma.xproce.inventoryservice.dao.repositeries.CoutFormationDAO;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.tomcat.util.http.fileupload.ByteArrayOutputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class CoutFormationManagerService implements CoutFormationManager {
    private final CoutFormationDAO coutFormationRepo;

    public ByteArrayInputStream generateWordDocument(Long id) {
        Optional<CoutFormation> optionalCoutFormation = coutFormationRepo.findById(id);

        if (!optionalCoutFormation.isPresent()) {
            throw new IllegalArgumentException("Invalid Ingenierie ID");
        }

        CoutFormation coutFormation = optionalCoutFormation.get();

        try (XWPFDocument document = new XWPFDocument()) {
            XWPFParagraph paragraph = document.createParagraph();
            XWPFRun run = paragraph.createRun();
            run.setText("Theme de l'action: " + coutFormation.getThemeAction());
            run.addBreak();
            run.setText("getEffectif: " + coutFormation.getEffectif());
            run.addBreak();
            run.setText("le noumbre de groupe: " + coutFormation.getNbrGrpe());
            run.addBreak();
            run.setText("la durée: " + coutFormation.getDuree());
            run.addBreak();
            run.setText("le préstataire: " + coutFormation.getPrestataire());
            run.addBreak();
            run.setText("le cout estimé par jour: " + coutFormation.getCoutEstimJ());
            run.addBreak();
            run.setText("le cout estimé total: " + coutFormation.getCoutEstimT());

            try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                document.write(out);
                return new ByteArrayInputStream(out.toByteArray());
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to generate Word document", e);
        }
    }



    @Autowired
    public CoutFormationManagerService(CoutFormationDAO coutFormationRepo) {
        this.coutFormationRepo = coutFormationRepo;
    }

    @Override
    public CoutFormation addCoutFormation(CoutFormation coutFormation) {
        return coutFormationRepo.save(coutFormation);
    }

    @Override
    public CoutFormation updateCoutFormation(CoutFormation coutFormation) {
        return coutFormationRepo.save(coutFormation);
    }

    @Override
    public boolean deleteCoutFormation(long id) {
        coutFormationRepo.deleteById(id);
        return true;
    }

    @Override
    public Page<CoutFormation> searchCoutFormation(String keyword, int page, int taille) {
        return coutFormationRepo.findByThemeActionContains(keyword, PageRequest.of(page, taille));
    }

    @Override
    public List<CoutFormation> getAllCoutFormation() {
        return coutFormationRepo.findAll();
    }

    @Override
    public CoutFormation getCoutFormationById(long id) {
        return coutFormationRepo.findById(id).orElse(null);
    }
}
