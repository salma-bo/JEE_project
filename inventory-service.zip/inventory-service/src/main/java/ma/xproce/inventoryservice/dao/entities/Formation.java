package ma.xproce.inventoryservice.dao.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;


@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Formation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nomFormation;

    private String description;
    private LocalDate dateDebut;
    private LocalDate dateFin;
    private String nomEntreprise;
    private static int numFormation =0;

    @ManyToOne
    private Creator creator;
    public Formation(long id, String nomFormation, LocalDate dateDebut, String nomEntreprise, String description, LocalDate dateFin) {
        this.nomFormation = nomFormation;

        this.nomEntreprise = nomEntreprise;
        this.description = description;

        this.creator = this.creator;
        numFormation++; // Assuming numFormation is a static variable tracking the number of formations
    }
// Keeping the same creator relationship, assuming it's still relevant

    @Override
    public String toString() {
        return "Formation{" +
                "id=" + id +
                ", nomFormation='" + nomFormation + '\'' +
                ", description='" + description + '\'' +
                ", dateDebut=" + dateDebut +
                ", dateFin=" + dateFin +
                ", nomEntreprise='" + nomEntreprise + '\'' +
                ", numFormation='" + numFormation + '\'' +
                '}';
    }

}
